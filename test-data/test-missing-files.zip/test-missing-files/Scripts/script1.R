print("Hello World")

source("../Source/source1.R")

read.csv("../Data/data.csv")

print(foo)
